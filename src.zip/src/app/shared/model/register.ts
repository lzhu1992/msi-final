export class Register {
  email: string;
  account: number;
  type: string;
  ssn: number;
  password: string;
}
