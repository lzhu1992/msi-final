export class Transfer {
  recipient: string;
  amount: string;
}
