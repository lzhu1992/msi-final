import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-logsuccess',
  templateUrl: './logsuccess.component.html',
  styleUrls: ['./logsuccess.component.scss']
})
export class LogsuccessComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
