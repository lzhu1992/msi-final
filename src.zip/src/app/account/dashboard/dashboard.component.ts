
import { RegisterService} from '../../shared/service/register.service';
import { Login } from '../../shared/model/login';
import { Dashboard } from '../../shared/model/dashboard';
import {Transaction} from '../../shared/model/transaction';
import {MatSort, MatTableDataSource, MatPaginator} from '@angular/material';
import {environment} from '../../../environments/environment';
import * as c3 from 'c3';
import {Sort} from '@angular/material';
import {Component, OnInit, ViewChild, ViewEncapsulation} from '@angular/core';

@Component({
  selector: 'app-dashboard',
  templateUrl: './dashboard.component.html',
  styleUrls: ['./dashboard.component.scss']
})
export class DashboardComponent implements OnInit {
  depositdat: number;
  name: string;
  sortedData;
  private PDF_LINK = `${environment.API_URL}` + '/transaction_pdf';


  displayedColumns = ['tdate', 'recipient', 'amount', 'deposit', 'describe'];
  dataSource: MatTableDataSource<Transaction> = new MatTableDataSource<Transaction>();
  @ViewChild(MatSort) sort: MatSort;
  @ViewChild(MatPaginator) paginator: MatPaginator;

  constructor(private rs: RegisterService) {
    this.sortedData = this.dataSource.data.slice();
  }

  ngOnInit() {
    console.log(this.rs.loggedin);
    this.rs.loggedin
      .subscribe(u => {
        this.rs.getDeposit(u)
          .then((dashboard: Dashboard) => {
            this.depositdat = dashboard.amount;
            this.name = dashboard.name;
          });
        this.rs.getTransaction(u)
          .subscribe(res => this.dataSource.data = res);
      });

    let chart = c3.generate({
      // bindto: '#chart',
      // data: {
      //   x: 'x',
      //   columns: [
      //     // ['data1', 30, 500, 100, 40, 8000, 250],
      //     ['x', 1 , 2, 4, 6, 8, 10],
      //     ['data1', 3, 20, 10, 40, 15, 25],
      //     ['data2', 200, 100, 800, 700, 500, 100],
      //   ],
      //   axes: {
      //     data2: 'y2'
      //   },
      //   types: {
      //     data2: 'bar' // ADD
      //   }
      // },
      // axis: {
      //   y: {
      //     label: {
      //       text: 'Y Label',
      //       position: 'outer-middle'
      //     },
      //
      //   },
      //   y2: {
      //     show: true,
      //     label: {
      //       text: 'Transaction History',
      //       position: 'outer-middle'
      //     }
      //   }
      // }
      data: {
        // iris data from R
        columns: [
          ['Shopping', 30],
          ['Eating', 120],
        ],
        type : 'pie',
        onclick: function (d, i) { console.log('onclick', d, i); },
        onmouseover: function (d, i) { console.log('onmouseover', d, i); },
        onmouseout: function (d, i) { console.log('onmouseout', d, i); }
      }
    });
    setTimeout(function () {
      chart.load({
        columns: [
          ['Shopping', 0.2, 0.2, 0.2, 0.2, 0.2, 0.4, 0.3, 0.2, 0.2, 0.1, 0.2, 0.2, 0.1, 0.1, 0.2, 0.4, 0.4, 0.3, 0.3, 0.3],
          ['Eating', 1.4, 1.5, 1.5, 1.3, 1.5, 1.3, 1.6, 1.0, 1.3, 1.4, 1.0, 1.5, 1.0, 1.4, 1.3, 1.4, 1.5, 1.0, 1.5, 1.1],
          ['Transportation', 2.5, 1.9, 2.1, 1.8, 2.2, 2.1, 1.7, 1.8, 1.8, 2.5, 2.0, 1.9, 2.1, 2.0, 2.4, 2.3, 1.8, 2.2, 2.3, 1.5],
        ]
      });
    }, 4000);

    setTimeout(function () {
      chart.unload({
        ids: 'Transfer'
      });
      chart.unload({
        ids: 'Recipient'
      });
    }, 3000);


  }
  applyFilter(filterValue: string) {
    filterValue = filterValue.trim(); // Remove whitespace
    filterValue = filterValue.toLowerCase(); // MatTableDataSource defaults to lowercase matches
    this.dataSource.filter = filterValue;
  }

  ngAfterViewInit() {
    this.dataSource.sort = this.sort;
    this.dataSource.paginator = this.paginator;
  }
  sortData(sort: Sort) {
    const data = this.dataSource.data .slice();
    if (!sort.active || sort.direction == '') {
      this.sortedData = data;
      return;
    }

    this.sortedData = data.sort((a, b) => {
      const isAsc = sort.direction == 'asc';
      switch (sort.active) {
        case 'tdate': return compare(a.tdate, b.tdate, isAsc);
        case 'recipient': return compare(+a.recipient, +b.recipient, isAsc);
        case 'amount': return compare(+a.amount, +b.amount, isAsc);
        case 'deposit': return compare(+a.deposit, +b.deposit, isAsc);
        case 'describe': return compare(+a.describe, +b.describe, isAsc);
        default: return 0;
      }
    });
  }
}

function compare(a, b, isAsc) {
  return (a < b ? -1 : 1) * (isAsc ? 1 : -1);
}


//
  // var chart = c3.generate({
  //     bindto: '#chart',
  //     data: {
  //       x: 'x',
  //       columns: [
  //         ['x', 2 , 6, 8, 10, 18, 20],
  //         ['data1', 200, 100, 800, 700, 500, 100],
  //       ],
  //       types: {
  //         data1: 'bar' // ADD
  //       }
  //     },
  //     axis: {
  //       y: {
  //         label: {
  //           text: 'transaction history of February',
  //           position: 'outer-middle'
  //         }
  //
  //       }
  //     }
  //   });

     // sortData(sort: Sort) {
     //    const data = this.dataSource.data.slice();
     //    if (!sort.active || sort.direction == '') {
     //    this.sortedData = data;
     //    return;
     //    }
     //
     //    this.sortedData = data.sort((a, b) => {
     //      const isAsc = sort.direction == 'asc';
     //      switch (sort.active) {
     //        case 'name':
     //          return compare(a.tdate, b.tdate, isAsc);
     //        case 'calories':
     //          return compare(+a.recipient, +b.recipient, isAsc);
     //        case 'fat':
     //          return compare(+a.amount, +b.amount, isAsc);
     //       case 'carbs':
     //          return compare(+a.deposit, +b.deposit, isAsc);
     //        case 'protein':
     //          return compare(+a.describe, +b.describe, isAsc);
     //       default:
     //          return 0;
     //      }
     //    });
     //  }

  // sortTransaction(){
  //   if(this.sortBy === "amount") {
  //     this.savings_trans.sort((a, b) => {return b.tran_date - a.tran_date});
  //   }else (this.sortBy === "recipient") {
  //     this.savings_trans.sort((a, b) => {return b.debit_credit - a.debit_credit});
  //   }

// function compare(a, b, isAsc) {
//   return (a < b ? -1 : 1) * (isAsc ? 1 : -1);
// }



