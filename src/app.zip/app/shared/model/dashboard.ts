export class Dashboard {
  name: string;
  account: number;
  amount: number;
}
