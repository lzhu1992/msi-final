export class Transaction {
  tdate: string;
  recipient: string;
  amount: number;
  deposit: string;
  describe: string;

}
